"""
Core Generation Logic - T2P System (Intelligent & Adaptive Version)
Features:
1. Self-healing (Feedback loop)
2. Mode-aware generation
3. Dynamic Topic Sampling (Optimization for complex exams)
"""
import time
import json
import random
import logging
from typing import List, Dict, Optional, Any
from datetime import datetime

# 导入业务模块
from config import Config
from gemini_client import GeminiClient
from prompt_builder import PromptBuilder
from postprocessor import PostProcessor
from evaluator import QualityEvaluator

logger = logging.getLogger(__name__)


class ProblemGenerator:
    """题目生成器 - 具备自愈能力、模式感知与动态采样优化"""

    def __init__(self, data_loader, gemini_client=None):
        """
        初始化生成器
        """
        self.data_loader = data_loader
        self.gemini_client = gemini_client or GeminiClient()

        # 初始化核心组件
        self.prompt_builder = PromptBuilder(data_loader)
        self.postprocessor = PostProcessor()
        # 传入 gemini_client 以便 Evaluator 执行 AI 深度评审
        self.evaluator = QualityEvaluator(data_loader, gemini_client=self.gemini_client)

        self.generated_problems = []

    def _sample_topics(self, topics: List[str], mode: str) -> List[str]:
        """
        动态主题采样策略：防止知识点过多导致模型逻辑崩溃
        """
        if mode == "drill":
            # 专项模式通常只针对一个或一组紧密相关的点，不采样
            return topics

        # 综合模式 (Exam) 优化
        count = len(topics)
        if count <= 5:
            return topics

        # 如果主题超过 5 个，随机选择 3-6 个进行组合
        # 既保证了难度，又确保了模型能写出高质量的逻辑链
        sample_size = random.randint(3, min(6, count))
        sampled = random.sample(topics, sample_size)
        logger.info(f"🎲 动态采样: 从 {count} 个主题中选择了 {sample_size} 个进行融合: {sampled}")
        return sampled

    def generate_one(self, topics: List[str], mode: str = "drill",
                     difficulty: int = 3, temperature: float = None) -> Optional[Dict]:
        """
        生成单道题目，具备 AI 评估反馈循环（自愈逻辑）
        """
        max_retries = Config.MAX_RETRIES
        current_feedback = ""  # 用于存放 Evaluator 的改进建议

        # 确保 topics 是列表
        if isinstance(topics, str):
            topics = [topics]

        # 【优化点】：在生成前进行主题采样
        active_topics = self._sample_topics(topics, mode)

        for attempt in range(max_retries):
            try:
                logger.info(f"生成任务 [模式:{mode} | 主题数:{len(active_topics)}] 尝试 {attempt + 1}/{max_retries}")

                # 1. 构建提示词 (注入采样后的主题和自愈反馈)
                prompt = self.prompt_builder.build_prompt(
                    topics=active_topics,
                    mode=mode,
                    difficulty=difficulty,
                    feedback=current_feedback
                )

                # 2. 调用 Gemini API
                response = self.gemini_client.generate(
                    prompt,
                    temperature=temperature or Config.DEFAULT_TEMPERATURE
                )

                if not response:
                    continue

                # 3. 后处理：清理与解析
                main_topic = active_topics[0] if mode == "drill" else "Multi-topic Integration"
                problem = self.postprocessor.process(response, main_topic)

                if not problem:
                    logger.warning(f"JSON 解析失败，触发下一次重试...")
                    continue

                # 4. 填充基础元数据
                problem.update({
                    'generated_at': datetime.now().isoformat(),
                    'model': self.gemini_client.model_name,
                    'mode': mode,
                    'target_difficulty': difficulty,
                    'integrated_topics': active_topics, # 记录实际融合的主题
                    'source_topics_pool': topics       # 保留原始请求的主题池
                })

                # 5. 核心：智能质量评估
                result = self.evaluator.evaluate(problem, active_topics)

                problem['evaluation'] = {
                    'score': result.score,
                    'dimensions': result.dimensions,
                    'passed': result.passed,
                    'issues': result.issues,
                    'ai_feedback': result.ai_feedback
                }

                if result.passed:
                    logger.info(f"✅ 质量达标 (得分: {result.score})")
                    return problem
                else:
                    # 自愈逻辑：提取反馈，用于下一轮重试
                    current_feedback = result.ai_feedback
                    logger.warning(f"⚠️ 质量未达标 (得分: {result.score})。反馈: {current_feedback}")
                    time.sleep(2 * (attempt + 1)) # 线性退避

            except Exception as e:
                logger.error(f"生成异常: {str(e)}", exc_info=True)
                time.sleep(2)

        return None

    def generate_batch(self, topics: List[str], num: int = 5,
                       mode: str = "drill", difficulty: int = 3) -> List[Dict]:
        """
        执行批量生成任务，并处理最终的去重
        """
        batch_result = []

        logger.info(f"===== 批量任务启动: {mode.upper()} 模式 =====")
        logger.info(f"🎯 总知识点池大小: {len(topics)}")

        for i in range(num):
            logger.info(f"正在生成第 {i+1}/{num} 道题目...")

            # 动态调整温度以确保多样性
            dynamic_temp = Config.DEFAULT_TEMPERATURE + (i * 0.05) % 0.25

            problem = self.generate_one(
                topics=topics,
                mode=mode,
                difficulty=difficulty,
                temperature=dynamic_temp
            )

            if problem:
                batch_result.append(problem)

            # 频率保护：避免触发 API 配额限制
            if i < num - 1:
                time.sleep(Config.REQUEST_DELAY)

        # 全局语义去重
        if batch_result:
            logger.info(f"正在对本批次 {len(batch_result)} 道题目进行语义去重...")
            unique_problems = self.postprocessor.deduplicate(batch_result)
            logger.info(f"去重完成: {len(batch_result)} -> {len(unique_problems)}")
            return unique_problems

        return []