"""
黄金数据集加载器 - 适配教育学原理增强版 (自适应导航优化版)
"""
import json
import random
from typing import Dict, List, Optional
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class GoldenDataLoader:
    """黄金数据集加载器 - 支持多级主题索引与模糊匹配"""

    def __init__(self, data_path: str):
        """
        初始化加载器
        Args:
            data_path: 黄金数据集JSON文件路径
        """
        self.data_path = Path(data_path)
        self.dataset = None
        self.problems = []
        self.topics_map = {}  # 结构: { "Topic Name": [problem_dict, ...] }
        self.load()

    def load(self):
        """加载数据集"""
        try:
            if not self.data_path.exists():
                logger.error(f"❌ 未找到数据集文件: {self.data_path}")
                return

            with open(self.data_path, 'r', encoding='utf-8') as f:
                self.dataset = json.load(f)

            # 提取题目列表
            if isinstance(self.dataset, dict) and 'problems' in self.dataset:
                self.problems = self.dataset['problems']
            elif isinstance(self.dataset, list):
                self.problems = self.dataset
            else:
                self.problems = []

            # 重新构建主题索引
            self._build_topic_map()

            logger.info(f"✅ 数据集加载成功：共 {len(self.problems)} 道题，"
                        f"已映射 {len(self.topics_map)} 个可用主题索引")

        except Exception as e:
            logger.error(f"❌ 加载数据集失败: {str(e)}")
            raise

    def _build_topic_map(self):
        """
        按大类和子类同时构建索引，并清理空格。
        确保 UserSession 里的 roadmap 只要命中其中一个层级就能获取数据。
        """
        self.topics_map = {}
        for p in self.problems:
            # 获取并清理名称
            main_topic = str(p.get('topic', 'unknown')).strip()
            sub_topic = str(p.get('sub_topic', '')).strip()

            # 1. 映射到大类
            if main_topic not in self.topics_map:
                self.topics_map[main_topic] = []
            self.topics_map[main_topic].append(p)

            # 2. 如果子类存在且不同，也映射到子类
            if sub_topic and sub_topic != main_topic:
                if sub_topic not in self.topics_map:
                    self.topics_map[sub_topic] = []
                self.topics_map[sub_topic].append(p)

    def get_topics(self) -> List[str]:
        """获取所有可用主题名称"""
        return list(self.topics_map.keys())

    def get_examples(self, topic: str, num_examples: int = 2) -> List[Dict]:
        """
        获取指定主题的示例题目 (带模糊匹配逻辑)
        """
        # 1. 尝试精确匹配 (忽略前后空格)
        search_key = topic.strip()
        examples = self.topics_map.get(search_key)

        # 2. 如果精确匹配失败，尝试模糊匹配 (大小写不敏感，且包含关键词)
        if not examples:
            logger.info(f"🔍 精确匹配 '{search_key}' 失败，尝试搜索相似主题...")
            for existing_key in self.topics_map.keys():
                if search_key.lower() in existing_key.lower() or \
                   existing_key.lower() in search_key.lower():
                    logger.info(f"💡 自动重定向到最接近的主题: '{existing_key}'")
                    examples = self.topics_map[existing_key]
                    break

        if not examples:
            logger.warning(f"⚠️ 警告: 主题 '{topic}' 及其变体在 dataset 中均无对应示例。")
            return []

        # 随机选择示例
        sample_size = min(num_examples, len(examples))
        return random.sample(examples, sample_size)

    def format_example(self, problem: Dict) -> str:
        """格式化为 JSON 供 LLM 学习"""
        return json.dumps(problem, indent=2, ensure_ascii=False)