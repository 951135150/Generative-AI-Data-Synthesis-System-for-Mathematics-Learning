import json
import time
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
import matplotlib.pyplot as plt
import numpy as np
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class UserSession:
    """
    UserSession 模块：管理用户学习生命周期，包含可视化能力。
    核心功能：学习路径导航、关卡晋升、时间追踪、持久化存储及学情图表生成。
    """

    def __init__(self, user_id: str, data_dir: str = "data/users"):
        self.user_id = user_id
        base_path = Path(__file__).resolve().parent.parent
        self.storage_path = base_path / data_dir / f"{user_id}_progress.json"
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)

        # --- 动态加载 Roadmap ---
        dataset_path = base_path / "data" / "golden_dataset_v2.json"
        self.roadmap = self._get_topics_from_dataset(dataset_path)

        self.progress = self._load_progress()
        self.session_start_time = None

    def _get_topics_from_dataset(self, path: Path) -> List[str]:
        """从数据集中动态提取所有主题，保持原始顺序"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                topics = []
                for p in data.get("problems", []):
                    t = p.get("topic")
                    if t and t not in topics:
                        topics.append(t)
                return topics
        except Exception as e:
            logger.error(f"无法读取数据集生成 Roadmap: {e}")
            # 如果读取失败，返回一个基础保底列表
            return ["Limits and Continuity", "Derivatives and Differentiation"]

    def _load_progress(self) -> Dict:
        """加载或初始化用户进度数据"""
        if self.storage_path.exists():
            try:
                with open(self.storage_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    # 检查是否需要迁移旧数据格式（确保 key 对齐）
                    for topic in self.roadmap:
                        if topic not in data["topics_status"]:
                            data["topics_status"][topic] = {
                                "mastery_score": 0.0,
                                "current_level": 1,
                                "completed_count": 0
                            }
                    return data
            except Exception as e:
                logger.warning(f"读取进度文件失败，重新初始化: {e}")

        # 初始化结构
        return {
            "metadata": {
                "user_id": self.user_id,
                "join_date": datetime.now().strftime("%Y-%m-%d"),
                "total_minutes": 0.0
            },
            "topics_status": {
                topic: {
                    "mastery_score": 0.0,  # 熟练度：0.0 到 1.0
                    "current_level": 1,  # 关卡：1(基础), 2(进阶/支架), 3(综合)
                    "completed_count": 0  # 刷题数量
                } for topic in self.roadmap
            },
            "learning_history": []
        }

    def start_learning(self):
        """开始学习会话"""
        self.session_start_time = time.time()
        logger.info(f"🔔 用户 {self.user_id} 学习会话开始。")

    def stop_learning(self):
        """结束会话并记录时间"""
        if self.session_start_time:
            duration = (time.time() - self.session_start_time) / 60
            self.progress["metadata"]["total_minutes"] += round(duration, 2)
            self.session_start_time = None
            self.save()

    def save(self):
        """持久化进度"""
        with open(self.storage_path, 'w', encoding='utf-8') as f:
            json.dump(self.progress, f, indent=4, ensure_ascii=False)

    def get_current_task_params(self) -> Dict:
        """自适应路径规划算法"""
        for topic in self.roadmap:
            status = self.progress["topics_status"][topic]
            if status["mastery_score"] < 0.85:
                level = status["current_level"]
                # 难度映射逻辑
                difficulty = 2 if level == 1 else (3 if level == 2 else 4)
                mode = "drill" if level < 3 else "exam"

                return {
                    "topic": topic,
                    "difficulty": difficulty,
                    "mode": mode,
                    "level": level
                }
        return {"topic": self.roadmap[-1], "difficulty": 5, "mode": "exam", "level": 3}

    def record_result(self, topic: str, score: float, is_passed: bool):
        """处理评估分数并更新体系"""
        # 容错处理：如果传入的 topic 在 roadmap 中找不到，尝试模糊匹配
        if topic not in self.progress["topics_status"]:
            found = False
            for r_topic in self.roadmap:
                if topic.lower().replace(" ", "") in r_topic.lower().replace(" ", ""):
                    topic = r_topic
                    found = True
                    break
            if not found:
                logger.warning(f"⚠️ 无法录入成绩：知识点 '{topic}' 不在教学大纲中。")
                return

        status = self.progress["topics_status"][topic]

        # 熟练度平滑更新 (Exponential Moving Average)
        old_mastery = status["mastery_score"]
        status["mastery_score"] = round(old_mastery * 0.3 + (score / 100) * 0.7, 2)
        status["completed_count"] += 1

        # 晋升逻辑
        if is_passed and score >= 80 and status["current_level"] < 3:
            status["current_level"] += 1
            logger.info(f"🎉 晋升！{topic} 升级到 Level {status['current_level']}")

        self.progress["learning_history"].append({
            "time": datetime.now().isoformat(),
            "topic": topic,
            "score": score,
            "level_at_time": status["current_level"]
        })
        self.save()

    def generate_visual_dashboard(self, save_path: str = "output/dashboard.png"):
        """可视化 Dashboard 生成"""
        # 确保输出目录存在
        out_p = Path(__file__).resolve().parent.parent / save_path
        out_p.parent.mkdir(parents=True, exist_ok=True)

        topics = self.roadmap
        # 优化标签显示：将长标题换行
        display_labels = [t.replace(" and ", " &\n") if len(t) > 15 else t for t in topics]
        mastery_scores = [self.progress["topics_status"][t]["mastery_score"] * 100 for t in topics]
        levels = [self.progress["topics_status"][t]["current_level"] for t in topics]

        fig = plt.figure(figsize=(16, 8))
        plt.suptitle(f"T2P Learning Analytics - {self.user_id}", fontsize=20, fontweight='bold', y=0.98)

        # 1. 雷达图
        ax1 = fig.add_subplot(121, polar=True)
        angles = np.linspace(0, 2 * np.pi, len(topics), endpoint=False).tolist()
        scores_c = mastery_scores + [mastery_scores[0]]
        angles_c = angles + [angles[0]]

        ax1.fill(angles_c, scores_c, color='#4A90E2', alpha=0.4)
        ax1.plot(angles_c, scores_c, color='#4A90E2', linewidth=2, marker='o')
        ax1.plot(angles_c, [85] * (len(topics) + 1), color='#E94E77', linestyle='--', label='Target (85%)')

        ax1.set_xticks(angles)
        ax1.set_xticklabels(display_labels, fontsize=10)
        ax1.set_title("Knowledge Mastery (%)", size=15, pad=30)
        ax1.legend(loc='upper right', bbox_to_anchor=(1.2, 1.1))

        # 2. 关卡柱状图
        ax2 = fig.add_subplot(122)
        colors = ['#7ED321' if l == 3 else ('#F5A623' if l == 2 else '#BDC3C7') for l in levels]
        bars = ax2.bar(topics, levels, color=colors, alpha=0.85, edgecolor='#2C3E50')

        ax2.set_xticks(range(len(topics)))
        ax2.set_xticklabels(display_labels, rotation=30, ha="right", fontsize=9)
        ax2.set_yticks([1, 2, 3])
        ax2.set_yticklabels(['L1: Novice', 'L2: Scaffolding', 'L3: Mastered'])
        ax2.set_title("Progression Status", size=15, pad=20)
        ax2.grid(axis='y', linestyle='--', alpha=0.6)

        # 标注练习次数
        for bar, t in zip(bars, topics):
            count = self.progress["topics_status"][t]["completed_count"]
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width() / 2., height + 0.05,
                     f'n={count}', ha='center', va='bottom', fontsize=9, fontweight='bold')

        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.savefig(str(out_p), dpi=300)
        plt.close()
        logger.info(f"📊 看板已更新: {out_p}")

    def generate_report(self):
        """终端文字报告"""
        print("\n" + "╔" + "═" * 58 + "╗")
        print(f"║ {('LEARNING REPORT: ' + self.user_id).center(56)} ║")
        print("╠" + "═" * 58 + "╣")
        print(f"║ ⏱️  Total Study Time: {self.progress['metadata']['total_minutes']:<32} ║")
        print("╟" + "─" * 58 + "╢")

        for topic in self.roadmap:
            data = self.progress["topics_status"][topic]
            icon = "🌟" if data["mastery_score"] >= 0.85 else "📈"
            bar_len = int(data['mastery_score'] * 20)
            p_bar = "█" * bar_len + "░" * (20 - bar_len)
            topic_str = (topic[:22] + "..") if len(topic) > 24 else topic
            print(
                f"║ {icon} {topic_str:<24} | L{data['current_level']} | {p_bar} {int(data['mastery_score'] * 100):>3}% ║")

        print("╚" + "═" * 58 + "╝\n")

        # 触发图片生成
        self.generate_visual_dashboard(save_path=f"output/dashboard_{self.user_id}.png")