"""
PostProcessor - Robust JSON & LaTeX Repair Version
加固重点：多级反斜杠修复、非法控制字符清洗、语义去重引擎优化
"""
import json
import re
from typing import Dict, List, Optional, Any
import logging
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

logger = logging.getLogger(__name__)


class PostProcessor:
    """后处理器 - 负责将 LLM 的原始输出转化为结构化教学数据"""

    def __init__(self, similarity_threshold: float = 0.85):
        self.similarity_threshold = similarity_threshold
        self.similarity_model = None
        try:
            # 使用支持多语言的轻量级模型，确保在处理中文/英文微积分题目时语义准确
            self.similarity_model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
            logger.info("✅ 语义去重引擎已就绪")
        except Exception as e:
            logger.warning(f"⚠️ 语义模型加载失败 (去重将降级为文本比对): {str(e)}")

    def clean_json_text(self, text: str) -> str:
        """
        极致加固的 JSON 清理逻辑
        """
        if not text:
            return ""

        # 1. 基础清理：去除 Markdown 标签及前后空白
        text = re.sub(r'^```json\s*|\s*```$', '', text.strip(), flags=re.MULTILINE)

        # 2. 定位真正的 JSON 块 (防止 AI 在 JSON 前后加解释性文字)
        start_idx = text.find('{')
        end_idx = text.rfind('}')
        if start_idx == -1 or end_idx == -1:
            return text
        text = text[start_idx:end_idx + 1]

        # 3. 【核心加固】LaTeX 反斜杠修复逻辑
        # 逻辑：我们要把 LaTeX 中的 \ 变成 \\，但不能影响 JSON 原有的转义（如 \n, \", \\）
        # 步骤 A: 先统一将已经转义过的 \\ 暂时替换为一个特殊占位符，防止被重复转义
        text = text.replace('\\\\', '___BACKSLASH_TEMP___')

        # 步骤 B: 寻找孤立的 \ (后面没有紧跟 json 合法转义符的)
        # 这里的正则匹配：一个反斜杠，后面不是 n, r, t, b, f, ", /, u
        text = re.sub(r'\\(?![nrtbf"/u])', r'\\\\', text)

        # 步骤 C: 将占位符还原回 \\
        text = text.replace('___BACKSLASH_TEMP___', '\\\\')

        # 4. 过滤非法控制字符 (0-31 范围，但保留 \n, \r, \t)
        # 很多时候 AI 会意外生成不可见的控制字符导致 json.loads 报错
        text = "".join(ch for ch in text if ord(ch) >= 32 or ch in "\n\r\t")

        return text

    def parse_json(self, text: str) -> Optional[Dict]:
        """具备二次回退机制的 JSON 解析"""
        cleaned = self.clean_json_text(text)
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            # 最后的挣扎：尝试修复常见的 JSON 末尾多余逗号问题
            try:
                fixed_comma = re.sub(r',\s*([\]}])', r'\1', cleaned)
                return json.loads(fixed_comma)
            except Exception as e:
                logger.error(f"❌ JSON 最终解析失败: {str(e)}")
                # 记录出错片段方便调试
                logger.debug(f"失败文本片段: {cleaned[:100]}...")
                return None

    def deduplicate(self, problems: List[Dict], existing: List[Dict] = None) -> List[Dict]:
        """
        基于语义向量的智能去重 (防止题目同质化)
        """
        if not problems:
            return []

        # 如果模型没加载成功，退回到基础文本去重
        if self.similarity_model is None:
            return self._basic_deduplicate(problems, existing)

        # 提取题目文本
        new_texts = [p.get('problem_statement', '') for p in problems]
        new_embeddings = self.similarity_model.encode(new_texts)

        # 构建对比池（历史题目向量）
        pool_embeddings = []
        if existing:
            existing_texts = [p.get('problem_statement', '') for p in existing if p.get('problem_statement')]
            if existing_texts:
                pool_embeddings = list(self.similarity_model.encode(existing_texts))

        unique_problems = []
        for i, emb in enumerate(new_embeddings):
            is_duplicate = False
            if pool_embeddings:
                # 计算与池中所有题目的相似度
                sims = cosine_similarity([emb], pool_embeddings)[0]
                max_sim = np.max(sims)
                if max_sim > self.similarity_threshold:
                    logger.info(f"🚫 过滤重复题目 (相似度: {max_sim:.2f})")
                    is_duplicate = True

            if not is_duplicate:
                unique_problems.append(problems[i])
                pool_embeddings.append(emb)  # 将新题加入对比池

        return unique_problems

    def _basic_deduplicate(self, problems: List[Dict], existing: List[Dict] = None) -> List[Dict]:
        """基础文本去重 (备选方案)"""
        seen = set()
        if existing:
            for p in existing:
                # 简单清洗后存入 fingerprint
                text = re.sub(r'\s+', '', p.get('problem_statement', ''))
                seen.add(text)

        unique = []
        for p in problems:
            text = re.sub(r'\s+', '', p.get('problem_statement', ''))
            if text not in seen:
                unique.append(p)
                seen.add(text)
        return unique

    def process(self, raw_text: str, topic: str = None) -> Optional[Dict]:
        """对外统一接口"""
        problem = self.parse_json(raw_text)
        if not problem:
            return None

        # 核心字段校验
        for field in ['problem_statement', 'solution', 'scaffolding']:
            if field not in problem:
                logger.warning(f"⚠️ 题目缺少必要字段: {field}")
                return None

        # 难度标准化
        try:
            d = int(problem.get('difficulty', 3))
            problem['difficulty'] = max(1, min(5, d))
        except:
            problem['difficulty'] = 3

        # 确保主题填充
        if topic:
            problem['topic'] = topic

        return problem