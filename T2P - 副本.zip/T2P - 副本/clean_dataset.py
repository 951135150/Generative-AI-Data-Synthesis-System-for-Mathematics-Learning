import json
import os
from pathlib import Path


def standardize_calculus_dataset(input_path: str, output_path: str):
    """
    针对 T2P 项目的数据清洗脚本：
    1. 统一 Topic 标签到 15 个标准核心模块。
    2. 将原有的细分标签移动到 sub_topic 字段。
    3. 确保数据一致性，优化 UserSession 的 Roadmap 生成。
    """

    # 1. 定义标准映射字典 (针对你数据集中的实际脏标签)
    topic_mapping = {
        # 导数类合并
        "Derivatives": "Derivatives and Differentiation",
        "Chain Rule": "Derivatives and Differentiation",
        "Partial Derivatives": "Multivariable Calculus",
        "L'Hôpital's Rule": "Derivatives and Differentiation",
        "Related Rates": "Applications of Derivatives",
        "Optimization": "Applications of Derivatives",

        # 积分类合并
        "Fundamental Theorem of Calculus": "Integration and FTOC",
        "Riemann Sums": "Integration and FTOC",
        "Definite Integrals": "Integration and FTOC",
        "Integration by Parts": "Techniques of Integration",
        "Volume of Revolution": "Applications of Integration",

        # 级数与多元类
        "Infinite Series": "Sequences and Series",
        "Taylor Series": "Sequences and Series",
        "Lagrange Multipliers": "Multivariable Calculus",
        "Green's Theorem": "Vector Calculus",
        "Polar Coordinates": "Parametric and Polar Curves",

        # 概念类
        "Intermediate Value Theorem": "Limits and Continuity",
        "Separable ODEs": "Differential Equations"
    }

    # 加载原始数据
    if not os.path.exists(input_path):
        print(f"❌ 错误：找不到文件 {input_path}")
        return

    with open(input_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    problems = data.get("problems", [])
    modified_count = 0

    print(f"🔍 正在处理 {len(problems)} 道题目...")

    # 2. 遍历并清洗
    for prob in problems:
        old_topic = prob.get("topic")

        if old_topic in topic_mapping:
            new_topic = topic_mapping[old_topic]

            # 如果原题目没有 sub_topic，把旧的 topic 存进去保留细节
            if not prob.get("sub_topic") or prob["sub_topic"] == old_topic:
                prob["sub_topic"] = old_topic

            # 更新为标准 Topic
            prob["topic"] = new_topic
            modified_count += 1

    # 3. 保存清洗后的数据
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    print(f"✅ 清洗完成！")
    print(f"📊 修改记录：{modified_count} 条标签已标准化。")
    print(f"💾 新数据集已保存至: {output_path}")


if __name__ == "__main__":
    # 获取当前项目的根目录路径
    base_dir = Path(__file__).resolve().parent
    input_file = base_dir / "data" / "golden_dataset_v2.json"
    output_file = base_dir / "data" / "golden_dataset_v2_standardized.json"

    standardize_calculus_dataset(str(input_file), str(output_file))