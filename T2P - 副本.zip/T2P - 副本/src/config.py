"""
配置文件 - 管理项目路径、Vertex AI 参数及生成控制
"""
import os
import logging
from pathlib import Path
from dotenv import load_dotenv

# 加载环境变量 (如果根目录下有 .env 文件)
load_dotenv()


class Config:
    """全局配置类"""

    # --- 基础路径配置 ---
    # Path(__file__).resolve() -> D:\PycharmBase\T2P\src\config.py
    # .parent.parent -> D:\PycharmBase\T2P
    BASE_DIR = Path(__file__).resolve().parent.parent

    # --- 资源路径 ---
    # 默认指向 D:\PycharmBase\T2P\data\golden_dataset_v2.json
    GOLDEN_DATASET_PATH = os.getenv("GOLDEN_DATASET_PATH", str(BASE_DIR / "data" / "golden_dataset_v2.json"))

    # 默认指向 D:\PycharmBase\T2P\output
    OUTPUT_DIR = os.getenv("OUTPUT_DIR", str(BASE_DIR / "output"))

    # 默认指向 D:\PycharmBase\T2P\logs\t2p_system.log
    LOG_FILE = os.getenv("LOG_FILE", str(BASE_DIR / "logs" / "t2p_system.log"))

    # --- Vertex AI 核心配置 ---
    PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT", "lu-mscds-t2p")
    LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "asia-east1")
    # 你确认 gemini-2.5-pro 在旧项目中运行良好，此处保持该 ID
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-pro")

    # --- 模型生成控制参数 (补全了 DEFAULT_TOP_P 和 DEFAULT_TOP_K) ---
    DEFAULT_TEMPERATURE = float(os.getenv("DEFAULT_TEMPERATURE", 0.5))
    DEFAULT_MAX_TOKENS = int(os.getenv("DEFAULT_MAX_TOKENS", 16384))
    DEFAULT_TOP_P = float(os.getenv("DEFAULT_TOP_P", 0.95))
    DEFAULT_TOP_K = int(os.getenv("DEFAULT_TOP_K", 40))

    # --- 运行调度配置 ---
    BATCH_SIZE = int(os.getenv("BATCH_SIZE", 5))
    REQUEST_DELAY = int(os.getenv("REQUEST_DELAY", 2))
    MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))

    # --- 日志级别 ---
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

    @classmethod
    def ensure_dirs(cls):
        """确保必要的目录存在"""
        Path(cls.OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
        Path(cls.LOG_FILE).parent.mkdir(parents=True, exist_ok=True)


# 自动初始化目录
Config.ensure_dirs()