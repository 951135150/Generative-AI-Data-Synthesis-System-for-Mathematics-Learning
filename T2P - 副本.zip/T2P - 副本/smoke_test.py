import logging
from postprocessor import PostProcessor

# 配置日志输出，方便观察过程
logging.basicConfig(level=logging.INFO)


def run_smoke_test():
    processor = PostProcessor()

    print("=== 开始冒烟测试 ===")

    # 模拟一个“最脏”的模型输出文本
    # 包含：Markdown 标签、未转义的 LaTeX、JSON 外部的废话
    raw_llm_output = r"""
        ```json
        {
          "problem_statement": "计算 $f(x) = \\sin(x^2)$ 的导数 \\frac{df}{dx}。",
          "scaffolding": [
            {"step": 1, "hint": "提示1"},
            {"step": 2, "hint": "提示2"},
            {"step": 3, "hint": "提示3"}
          ],
          "difficulty": 3,
          "solution": "2x \\cos(x^2)"
        }
        ```
        """

    try:
        # 1. 测试清理逻辑
        cleaned_text = processor.clean_json_text(raw_llm_output)
        print("Step 1: 清理后的文本片段:")
        print(cleaned_text[:100] + "...")

        # 2. 测试解析逻辑
        result = processor.parse_json(raw_llm_output)

        if result and isinstance(result, dict):
            print("✅ Step 2: JSON 解析成功！")
            print(f"题目详情: {result.get('problem_statement')}")
        else:
            print("❌ Step 2: 解析返回为空或格式错误")
            return

        # 3. 测试后处理流程（难度修复等）
        processed_result = processor.process(raw_llm_output, topic="Derivatives")
        if processed_result and processed_result.get('difficulty') == 3:
            print("✅ Step 3: 后处理流程完整通过（包括难度修复）")
        else:
            print("❌ Step 3: 后处理流程异常")

    except Exception as e:
        print(f"💥 冒烟测试崩溃: {str(e)}")
        return

    print("=== 冒烟测试通过！代码可以继续集成 ===")


if __name__ == "__main__":
    run_smoke_test()