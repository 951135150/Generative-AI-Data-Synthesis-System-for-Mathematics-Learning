"""
T2P: 微积分题目自动化生成系统 - 智能交互版
支持：专项训练 (Drill) 与 综合考题 (Exam) 模式
"""
import argparse
import logging
import sys
from pathlib import Path

# --- 关键路径适配逻辑 ---
root_dir = Path(__file__).resolve().parent
src_dir = root_dir / "src"
if src_dir.exists() and str(src_dir) not in sys.path:
    sys.path.insert(0, str(src_dir))

# --- 导入业务模块 ---
try:
    from config import Config
    from batch_generator import BatchGenerator
except ImportError as e:
    print(f"❌ 启动失败: 找不到核心模块 ({e})")
    print(f"请检查目录结构，确保 {src_dir} 目录下有 __init__.py 文件。")
    sys.exit(1)


def setup_logging():
    """配置系统日志"""
    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    log_file = Path(Config.LOG_FILE)
    log_file.parent.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        level=getattr(logging, Config.LOG_LEVEL, logging.INFO),
        format=log_format,
        handlers=[
            logging.FileHandler(str(log_file), encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )


def print_banner():
    """打印欢迎横幅"""
    banner = """
    ================================================
    |           T2P: Term 2 Project                |
    |    AI-Driven Calculus Problem Synthesizer    |
    ================================================
    """
    print(banner)


def main():
    """程序主入口"""
    parser = argparse.ArgumentParser(
        description='📐 T2P: 基于教育学原理的微积分题目合成系统',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    # 核心模式与参数
    group = parser.add_argument_group('生成配置')
    group.add_argument('--mode', type=str, choices=['drill', 'exam'], default='drill',
                        help='生成模式: drill(专项训练) 或 exam(综合考题)')
    group.add_argument('--topics', nargs='+', help='指定主题 (专项模式取首个，综合模式融合所有)')
    group.add_argument('--num', type=int, default=5, help='生成的题目总数')
    group.add_argument('--difficulty', type=int, choices=[1, 2, 3, 4, 5], default=3,
                        help='目标难度等级 (1-5)')

    # 辅助功能
    aux = parser.add_argument_group('辅助功能')
    # 支持连字符和下划线两种写法，防止命令行输入习惯导致报错
    aux.add_argument('--batch-name', '--batch_name', type=str, help='自定义批次名称')
    aux.add_argument('--stats', action='store_true', help='显示历史生成统计摘要')
    aux.add_argument('--list-topics', action='store_true', help='列出题库中所有可用主题')

    if len(sys.argv) == 1:
        print_banner()
        parser.print_help()
        return

    args = parser.parse_args()
    setup_logging()
    logger = logging.getLogger("Main")

    try:
        # 初始化调度器
        generator = BatchGenerator()

        # 处理 --list-topics 逻辑
        if args.list_topics:
            topics = generator.data_loader.get_topics()
            print("\n📚 题库可用核心知识点 (Golden Dataset):")
            print("-" * 50)
            for i, topic in enumerate(topics, 1):
                count = len(generator.data_loader.topics_map.get(topic, []))
                print(f"  {i:02d}. {topic:<30} (种子数: {count})")
            print("-" * 50)
            return

        # 处理 --stats 逻辑
        if args.stats:
            stats = generator.get_statistics()
            print("\n📊 T2P 系统运行统计")
            print("=" * 40)
            print(f"🔹 累计生成批次: {stats['total_batches']}")
            print(f"🔹 累计生成题目: {stats['total_problems']}")
            if 'mode_distribution' in stats:
                print(f"🔹 模式分布: Drill({stats['mode_distribution']['drill']}) | Exam({stats['mode_distribution']['exam']})")
            print("=" * 40)
            return

        # 确定生成目标
        target_topics = args.topics
        if not target_topics:
            if args.mode == 'drill':
                print("❌ 错误: 专项训练模式 (Drill) 必须使用 --topics 指定至少一个主题。")
                return
            else:
                target_topics = generator.data_loader.get_topics() # 综合模式默认全选

        # 界面反馈
        print_banner()
        print(f"🚀 任务启动中...")
        print(f"📝 运行模式: {args.mode.upper()}")
        print(f"🎯 涉及主题: {', '.join(target_topics)}")
        print(f"📈 难度设定: {args.difficulty}/5")
        print(f"🔢 生成数量: {args.num}")
        if args.batch_name:
            print(f"🏷️ 批次标签: {args.batch_name}")
        print("-" * 40)

        # 【核心修复点】:
        # 不要直接调用 generator.generator.generate_batch (它只返回 list)
        # 应该调用调度层 generator.generate (它负责保存文件并返回包含 batch_id 的 dict)
        result = generator.generate(
            topics=target_topics,
            num=args.num,
            mode=args.mode,
            difficulty=args.difficulty,
            batch_name=args.batch_name
        )

        # 输出结果摘要
        # 此时 result 是 BatchGenerator.generate 返回的字典，包含 batch_id
        batch_id = result.get('batch_id', 'unknown')
        output_file_path = generator.output_dir / f"{batch_id}.json"

        print(f"\n" + "★" * 48)
        print(f"✅ 任务顺利完成!")
        print(f"🆔 任务批次: {batch_id}")
        print(f"📂 保存路径: {output_file_path}")
        print(f"💡 提示: 您可以查看 JSON 文件中的 'scaffolding' 字段来检查教学支架逻辑。")
        print("★" * 48 + "\n")

    except KeyboardInterrupt:
        print("\n⚠️ 操作被用户中断。")
    except Exception as e:
        logger.error(f"程序运行异常: {str(e)}", exc_info=True)
        print(f"\n❌ 系统发生故障，详细错误已记录至日志。")
        sys.exit(1)


if __name__ == '__main__':
    main()