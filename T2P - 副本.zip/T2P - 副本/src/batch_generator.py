"""
Batch Generator - Intelligent Orchestrator
Updated to support Adaptive Learning Modes: Drill & Exam.
"""
import json
import os
import logging
from typing import List, Dict, Optional
from datetime import datetime
from pathlib import Path

# 从 src 目录导入业务模块
from config import Config
from data_loader import GoldenDataLoader
from gemini_client import GeminiClient
from generator import ProblemGenerator

logger = logging.getLogger(__name__)


class BatchGenerator:
    """批量生成调度器 - 支持自适应学习模式"""

    def __init__(self, output_dir: str = None):
        """
        初始化调度器
        Args:
            output_dir: 输出目录
        """
        self.output_dir = Path(output_dir or Config.OUTPUT_DIR)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 加载黄金数据
        self.data_loader = GoldenDataLoader(Config.GOLDEN_DATASET_PATH)

        # 创建生成器 (ProblemGenerator 内部持有 Evaluator 和 PostProcessor)
        self.generator = ProblemGenerator(self.data_loader)

        # 记录生成历史
        self.history_file = self.output_dir / "generation_history.json"
        self.history = self._load_history()

    def _load_history(self) -> Dict:
        """加载生成历史摘要"""
        if self.history_file.exists():
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict) and 'batches' in data:
                        return data
            except Exception as e:
                logger.warning(f"读取历史文件失败: {e}")
        return {'batches': []}

    def _save_history(self):
        """保存生成历史摘要"""
        try:
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(self.history, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存历史文件失败: {e}")

    def generate(self, topics: List[str] = None, num: int = 5,
                 mode: str = "drill", difficulty: int = 3,
                 batch_name: str = None) -> Dict:
        """
        执行智能生成流程

        Args:
            topics: 主题列表
            num: 生成的总题目数
            mode: "drill" (专项) 或 "exam" (综合)
            difficulty: 目标难度 (1-5)
            batch_name: 批次备注名称
        """
        if not topics:
            topics = self.data_loader.get_topics()

        logger.info(f"开始任务 | 模式: {mode.upper()} | 目标数量: {num} | 难度: {difficulty}")

        final_problems = []

        # --- 核心逻辑分发 ---
        if mode == "exam":
            # 综合模式：每一道题都融合传入的所有 topics
            logger.info(f"进入模拟考试模式，正在融合主题: {topics}")
            for i in range(num):
                # 传入整个 topics 列表，触发 PromptBuilder 的综合逻辑
                prob = self.generator.generate_one(topics, mode=mode, difficulty=difficulty)
                if prob:
                    final_problems.append(prob)
        else:
            # 专项模式：针对 topics 列表中的主题进行循环生成
            # 比如 topics=["Limits"], num=5，则生成5道 Limits 题
            target_topic = topics[0]
            logger.info(f"进入专项训练模式，目标主题: {target_topic}")
            for i in range(num):
                # 动态微调温度以增加样题库的丰富度
                temp = Config.DEFAULT_TEMPERATURE + (i * 0.05) % 0.3
                prob = self.generator.generate_one([target_topic], mode=mode, difficulty=difficulty, temperature=temp)
                if prob:
                    final_problems.append(prob)

        # --- 后处理：语义去重 ---
        if final_problems:
            original_count = len(final_problems)
            final_problems = self.generator.postprocessor.deduplicate(final_problems)
            if len(final_problems) < original_count:
                logger.info(f"语义去重已过滤 {original_count - len(final_problems)} 道相似题目")

        # 构建批次详情
        batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        batch_result = {
            'batch_id': batch_id,
            'batch_name': batch_name or f"{mode}_{batch_id[-6:]}",
            'mode': mode,
            'generated_at': datetime.now().isoformat(),
            'target_topics': topics,
            'difficulty_setting': difficulty,
            'total_generated': len(final_problems),
            'problems': final_problems
        }

        # 持久化存储结果 JSON
        output_file = self.output_dir / f"{batch_id}.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(batch_result, f, ensure_ascii=False, indent=2)

        # 更新摘要历史
        self.history['batches'].append({
            'batch_id': batch_id,
            'mode': mode,
            'topics': topics,
            'total_generated': len(final_problems),
            'generated_at': batch_result['generated_at']
        })
        self._save_history()

        return batch_result

    def get_statistics(self) -> Dict:
        """获取系统运行统计摘要"""
        all_batches = self.history.get('batches', [])
        stats = {
            'total_batches': len(all_batches),
            'total_problems': sum(b.get('total_generated', 0) for b in all_batches),
            'mode_distribution': {
                'drill': len([b for b in all_batches if b.get('mode') == 'drill']),
                'exam': len([b for b in all_batches if b.get('mode') == 'exam'])
            }
        }

        # 计算质量得分
        scores = []
        for batch in all_batches:
            batch_file = self.output_dir / f"{batch['batch_id']}.json"
            if batch_file.exists():
                try:
                    with open(batch_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        for p in data.get('problems', []):
                            # 从内部 evaluation 对象提取分数
                            s = p.get('evaluation', {}).get('score')
                            if s: scores.append(s)
                except: continue

        stats['avg_score'] = sum(scores) / len(scores) if scores else 0
        return stats