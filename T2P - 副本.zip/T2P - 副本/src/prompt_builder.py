"""
Prompt Builder - Advanced Agentic Version (V2.5 - Logic Reinforced)
Supports:
1. Multi-mode (Drill & Exam)
2. Self-healing (Feedback loop)
3. Pedagogical Principles (Scaffolding, Multiple Representations)
4. Mathematical Consistency & Logic Guardrails
"""
import json
import random
from typing import List, Dict, Optional
import logging

logger = logging.getLogger(__name__)

class PromptBuilder:
    """提示词构建器 - 深度整合自愈逻辑、教学法原则与数学逻辑约束"""

    def __init__(self, data_loader):
        """
        初始化构建器
        Args:
            data_loader: GoldenDataLoader 实例
        """
        self.data_loader = data_loader

    def build_prompt(self, topics: List[str], mode: str = "drill",
                     difficulty: int = 3, feedback: str = "") -> str:
        """
        统一入口：构建包含自愈信息的提示词
        """
        if isinstance(topics, str):
            topics = [topics]

        if mode == "exam" or len(topics) > 1:
            # 综合模式：侧重逻辑链条和多知识点融合
            prompt = self._build_exam_prompt(topics, difficulty)
        else:
            # 专项模式：侧重单一知识点的深度和变体
            target_topic = topics[0] if topics else "Calculus Fundamentals"
            prompt = self._build_drill_prompt(target_topic, difficulty)

        # 注入自愈反馈 (Self-healing Injection)
        if feedback:
            healing_block = (
                f"\n\n[!!! CRITICAL: SELF-HEALING FEEDBACK FROM PREVIOUS ATTEMPT !!!]\n"
                f"Your previous output failed quality evaluation: '{feedback}'\n"
                f"INSTRUCTION: You MUST adjust the numerical values, logic flow, or pedagogical clarity "
                f"to resolve these specific issues while keeping the JSON schema intact."
            )
            prompt += healing_block

        return prompt

    def _get_base_role(self) -> str:
        return (
            "ROLE: You are a Senior Calculus Pedagogy Researcher. "
            "Your goal is to generate mathematically rigorous, logically consistent, and pedagogically sound problems."
        )

    def _get_logic_guardrails(self) -> str:
        """注入数学逻辑防幻觉约束"""
        return (
            "\n[STRICT MATHEMATICAL LOGIC RULES]:\n"
            "1. NUMERICAL VERIFICATION: Before outputting, mentally verify that the problem is solvable. "
            "For IVT (Intermediate Value Theorem), ensure f(a) and f(b) have opposite signs. "
            "For Limits, ensure the expression is not trivially divergent unless intended.\n"
            "2. GEOMETRIC CONSISTENCY: In Volume/Area problems, verify if functions intersect. "
            "Ensure the resulting volume is physically positive; do not use 'absolute value' to fix negative integrals.\n"
            "3. METHOD COMPATIBILITY: Do not force redundant methods. For example, if a student uses Taylor Series "
            "to solve a limit, do not mandate L'Hôpital's Rule in the same step.\n"
            "4. STRUCTURAL COHESION: In multi-part problems (Part A, B, C), the numerical result of Part A "
            "MUST be used as an input parameter for Part B to create a cohesive logical chain."
        )

    def _get_pedagogical_principles(self, is_comprehensive: bool = False) -> str:
        principles = [
            "1. SCAFFOLDING: Hints must guide the 'thinking process' (e.g., 'What does the sign of the second derivative tell us about the drone's acceleration?').",
            "2. MULTIPLE REPRESENTATIONS: Provide an 'Algebraic' solution and a 'Visual/Conceptual' explanation.",
            "3. REAL-WORLD CONTEXT: Use high-level scenarios (e.g., Data Science optimization, Fintech modeling, Physics)."
        ]
        if is_comprehensive:
            principles.append("4. INTEGRATION: Seamlessly bridge topics. Don't just list questions; build a narrative.")
        return "\nCORE PEDAGOGICAL PRINCIPLES:\n" + "\n".join(principles)

    def _build_drill_prompt(self, topic: str, difficulty: int) -> str:
        examples = self.data_loader.get_examples(topic, 2)
        prompt_parts = [
            self._get_base_role(),
            f"\nTASK: Generate a high-quality DRILL problem for: '{topic}'.",
            f"DIFFICULTY LEVEL: {difficulty}/5.",
            self._get_logic_guardrails(),
            self._get_pedagogical_principles(is_comprehensive=False)
        ]

        if examples:
            prompt_parts.append("\nREFERENCE EXAMPLES:")
            for ex in examples:
                brief = {"problem": ex.get('problem_statement'), "solution": ex.get('solution')}
                prompt_parts.append(json.dumps(brief, ensure_ascii=False))

        prompt_parts.append(self._get_output_schema_and_constraints(topic))
        return "\n".join(prompt_parts)

    def _build_exam_prompt(self, topics: List[str], difficulty: int) -> str:
        prompt_parts = [
            self._get_base_role(),
            f"\nTASK: Create an INTEGRATED EXAM problem combining: {', '.join(topics)}.",
            f"DIFFICULTY LEVEL: {difficulty}/5.",
            self._get_logic_guardrails(),
            self._get_pedagogical_principles(is_comprehensive=True),
            "\n[EXAM CONSTRUCTION STRATEGY]:\n"
            "- Start with a complex real-world system (e.g., Fluid Dynamics, Neural Network Cost Optimization).\n"
            "- Part A: Initial modeling (e.g., Derivatives/Related Rates).\n"
            "- Part B: Systems Analysis (e.g., ODEs/Integration).\n"
            "- Part C: Advanced Synthesis (e.g., Taylor Approximation/Vector Calculus)."
        ]

        prompt_parts.append(self._get_output_schema_and_constraints(", ".join(topics)))
        return "\n".join(prompt_parts)

    def _get_output_schema_and_constraints(self, topic_str: str) -> str:
        schema = {
            "problem_statement": "LaTeX text.",
            "real_world_context": "Scenario description.",
            "difficulty": "1-5",
            "scaffolding": [{"step": 1, "hint": "..."}],
            "multiple_representations": {"algebraic": "...", "visual_conceptual": "..."},
            "solution": "Step-by-step LaTeX.",
            "concepts": ["Concept A", "Concept B"]
        }

        return (
            f"\nTARGET TOPIC(S): {topic_str}"
            "\n[STRICT OUTPUT RULE]: RETURN ONLY RAW JSON. NO MARKDOWN. NO PREFACE."
            "\nJSON STRUCTURE:"
            f"\n{json.dumps(schema, indent=2)}"
            "\n\nLATEX & JSON ESCAPING CONSTRAINTS:"
            "\n- Use '$...$' for inline and '$$...$$' for block math."
            "\n- IMPORTANT: You MUST use TRIPLE BACKSLASHES for LaTeX commands within the JSON string "
            "(e.g., '\\\\\\\\frac{dy}{dx}' or '\\\\\\\\int') to ensure the parser handles it correctly."
            "\n- Avoid complex nested fractions in scaffolding hints to keep them readable."
        )