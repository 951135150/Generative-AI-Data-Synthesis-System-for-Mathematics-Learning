import sys
from pathlib import Path

# --- 关键路径适配：让脚本能找到 src 目录下的模块 ---
root_dir = Path(__file__).resolve().parent
src_dir = root_dir / "src"
if src_dir.exists() and str(src_dir) not in sys.path:
    sys.path.insert(0, str(src_dir))
# ----------------------------------------------

import json
import logging
from pathlib import Path
from src.batch_generator import BatchGenerator
from src.config import Config

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("DatasetExpander")


def expand_golden_dataset(target_count=10):
    # 1. 初始化现有的调度器
    batch_gen = BatchGenerator()
    data_loader = batch_gen.data_loader
    output_path = Path(Config.GOLDEN_DATASET_PATH)

    # 获取当前所有主题
    topics = data_loader.get_topics()
    logger.info(f"开始扩充任务，目标：每个主题 {target_count} 道题。当前主题数：{len(topics)}")

    all_new_problems = []

    for topic in topics:
        current_probs = data_loader.topics_map.get(topic, [])
        needed = target_count - len(current_probs)

        if needed <= 0:
            logger.info(f"✅ 主题 '{topic}' 已达标 (现有 {len(current_probs)} 道)")
            continue

        logger.info(f"⏳ 正在为 '{topic}' 生成 {needed} 道高质量题目...")

        # 2. 调用现有的 generate_batch，设置 mode='drill'
        # 我们利用现有的自愈和评估逻辑
        results = batch_gen.generator.generate_batch(
            topics=[topic],
            num=needed,
            mode="drill",
            difficulty=3  # 种子数据建议设定在中等难度
        )

        # 3. 筛选极高标准的题目放入黄金集
        for prob in results:
            # 只有评估分数 > 85 且通过逻辑校验的才进黄金集
            if prob.get('evaluation', {}).get('score', 0) >= 85:
                # 移除生成时的临时字段，保持黄金数据集纯净
                clean_prob = {
                    "problem_id": f"EXT_{topic[:3].upper()}_{len(all_new_problems):03d}",
                    "topic": prob.get("topic", topic),
                    "sub_topic": topic,
                    "difficulty": prob.get("difficulty"),
                    "problem_statement": prob.get("problem_statement"),
                    "scaffolding": prob.get("scaffolding"),
                    "solution": prob.get("solution"),
                    "real_world_context": prob.get("real_world_context"),
                    "concepts": prob.get("concepts")
                }
                all_new_problems.append(clean_prob)

    # 4. 回写文件
    if all_new_problems:
        # 读取原文件内容
        with open(output_path, 'r', encoding='utf-8') as f:
            full_data = json.load(f)

        # 合并数据
        if isinstance(full_data, dict) and 'problems' in full_data:
            full_data['problems'].extend(all_new_problems)
            full_data['dataset_info']['total_problems'] = len(full_data['problems'])
        else:
            # 兼容纯列表格式
            full_data.extend(all_new_problems)

        # 备份并保存
        backup_path = output_path.with_suffix('.json.bak')
        output_path.rename(backup_path)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(full_data, f, indent=2, ensure_ascii=False)

        logger.info(f"🎊 扩充完成！成功添加 {len(all_new_problems)} 道题目至 {output_path}")
    else:
        logger.info("ℹ️ 没有符合高质量标准的题目产生，未修改文件。")


if __name__ == "__main__":
    expand_golden_dataset(target_count=10)