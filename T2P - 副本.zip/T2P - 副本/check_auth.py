import google.auth
from google import genai
from config import Config


def diagnose():
    credentials, project_id = google.auth.default()
    print(f"--- 身份诊断 ---")
    print(f"当前使用的 Project ID: {project_id}")
    print(f"配置文件中的 Project ID: {Config.PROJECT_ID}")
    print(f"当前身份账号: {getattr(credentials, 'service_account_email', '个人账号/ADC')}")

    try:
        client = genai.Client(vertexai=True, project=Config.PROJECT_ID, location=Config.LOCATION)
        # 获取该区域下所有可用的模型列表
        print(f"\n--- 正在拉取 {Config.LOCATION} 可用模型列表 ---")
        models = client.models.list()
        found = False
        for m in models:
            if "gemini" in m.name:
                print(f"发现可用模型: {m.name}")
                found = True
        if not found:
            print("❌ 未发现任何 Gemini 系列模型，请检查 API 是否开启或结算账户是否欠费。")
    except Exception as e:
        print(f"❌ 列表获取失败: {e}")


if __name__ == "__main__":
    diagnose()