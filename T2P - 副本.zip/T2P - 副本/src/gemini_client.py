import logging
import time
from google import genai
from google.genai import types
from config import Config

logger = logging.getLogger(__name__)


class GeminiClient:
    def __init__(self):
        """初始化 Vertex AI 客户端 - 极致兼容版"""
        try:
            self.client = genai.Client(
                vertexai=True,
                project=Config.PROJECT_ID,
                location=Config.LOCATION
            )

            # 提取模型 ID (例如 gemini-2.5-pro)
            raw_id = str(Config.GEMINI_MODEL).strip()
            self.model_name = raw_id.split('/')[-1]

            logger.info(f"✅ T2P 系统就绪 | 模型: {self.model_name}")

        except Exception as e:
            logger.error(f"❌ 客户端初始化失败: {str(e)}")
            raise

    def generate(self, prompt, **kwargs):
        """
        高兼容性生成方法 - 移除了可能引起歧义的 http_options
        """
        # 1. 严格使用 types 构造配置
        generate_config = types.GenerateContentConfig(
            temperature=kwargs.get('temperature', Config.DEFAULT_TEMPERATURE),
            max_output_tokens=Config.DEFAULT_MAX_TOKENS,
            top_p=Config.DEFAULT_TOP_P,
            top_k=Config.DEFAULT_TOP_K,
            response_mime_type="application/json"
        )

        for attempt in range(Config.MAX_RETRIES):
            try:
                logger.info(f"正在请求 Vertex AI (尝试 {attempt + 1}/{Config.MAX_RETRIES})...")

                # 2. 移除 http_options 参数，使用 SDK 默认超时 (通常为 60-120s)
                # 这能彻底解决 "unexpected keyword argument" 报错
                response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=prompt,
                    config=generate_config
                )

                if response and response.text:
                    return response.text

                logger.warning(f"⚠️ 响应体为空 (尝试 {attempt + 1})")

            except Exception as e:
                err_msg = str(e)
                logger.error(f"❌ 生成错误: {err_msg}")

                # 针对常见错误进行重试
                if attempt < Config.MAX_RETRIES - 1:
                    wait_time = (attempt + 1) * 5
                    logger.info(f"🔄 将在 {wait_time} 秒后重试...")
                    time.sleep(wait_time)
                else:
                    # 只有在最后一次尝试失败时才抛出异常给上层 generator
                    return None

        return None