"""
Quality Evaluator - Intelligent & Robust Version
Features: LLM-as-a-Judge, Self-healing Feedback, and Strict Math Verification.
"""
import json
import logging
import re
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from gemini_client import GeminiClient

logger = logging.getLogger(__name__)

@dataclass
class EvaluationResult:
    """评估结果数据类"""
    score: float
    dimensions: Dict[str, float]
    issues: List[str]
    passed: bool
    ai_feedback: str = ""

class QualityEvaluator:
    """智能质量评估器 - 负责 T2P 系统的闭环质量控制"""

    def __init__(self, golden_data_loader=None, gemini_client=None):
        self.golden_loader = golden_data_loader
        self.gemini_client = gemini_client or GeminiClient()

        # 优化后的权重分配
        self.weights = {
            'structure': 0.10,          # 基础 JSON 结构
            'math_logic': 0.30,         # 数学逻辑准确性 (权重最高)
            'scaffolding': 0.20,        # 支架式教学质量
            'pedagogical_alignment': 0.20, # 教育学原则对齐
            'concept_integration': 0.10, # 跨知识点融合度
            'originality': 0.10         # 原创性
        }

    def _extract_json(self, text: str) -> Dict:
        """从模型返回的文本中安全提取 JSON"""
        try:
            # 匹配最外层的花括号内容
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if match:
                return json.loads(match.group())
            return json.loads(text)
        except Exception:
            return {}

    def _evaluate_with_llm(self, problem: Dict, expected_topics: List[str]) -> Dict[str, Any]:
        """利用 AI 进行专家级评审"""
        review_prompt = f"""
        [ROLE] Senior Mathematics Education Auditor
        [TASK] Critically evaluate this synthesized calculus problem.
        
        [DATA]
        Topics: {expected_topics}
        Problem: {json.dumps(problem, indent=2)}

        [RUBRIC]
        1. Accuracy: Is the mathematical derivation in the 'solution' 100% correct?
        2. Scaffolding: Does the 'scaffolding' guide thought without revealing the answer?
        3. Context: Is the 'real_world_context' meaningful or just filler?
        4. Integration: Do the topics connect logically?

        [OUTPUT] Return ONLY a JSON:
        {{
            "math_logic_score": 0-100,
            "pedagogical_score": 0-100,
            "integration_score": 0-100,
            "is_mathematically_correct": true/false,
            "critical_flaw": "Identify one major issue if any",
            "improvement_suggestion": "How to make this problem better for a student?"
        }}
        """
        try:
            response = self.gemini_client.generate(review_prompt, temperature=0.1) # 低温保证稳定性
            return self._extract_json(response)
        except Exception as e:
            logger.error(f"AI 评审连接中断: {e}")
            return {"is_mathematically_correct": False, "math_logic_score": 0}

    def evaluate(self, problem: Dict, target_topics: List[str] = None) -> EvaluationResult:
        """执行综合审计流程"""
        dimensions = {}
        all_issues = []

        # 1. 结构化硬性校验
        required = ['problem_statement', 'scaffolding', 'solution', 'multiple_representations']
        struct_score = 100 - sum(20 for f in required if f not in problem)
        dimensions['structure'] = max(0, struct_score)

        # 2. AI 深度审计
        ai_review = self._evaluate_with_llm(problem, target_topics or [])

        dimensions['math_logic'] = ai_review.get('math_logic_score', 0)
        dimensions['pedagogical_alignment'] = ai_review.get('pedagogical_score', 0)
        dimensions['scaffolding'] = ai_review.get('pedagogical_score', 0) # 细分指标
        dimensions['concept_integration'] = ai_review.get('integration_score', 0)

        # 3. 原创性 (基于 Data Loader)
        dimensions['originality'] = 100 # 默认分
        if self.golden_loader and problem.get('problem_statement'):
            # 简单的文本重叠度预判
            if any(p.get('problem_statement')[:30] in problem['problem_statement']
                   for p in self.golden_loader.problems[:5]):
                dimensions['originality'] = 40
                all_issues.append("Detected high similarity with Golden Dataset.")

        # 4. 汇总分数
        total_score = sum(dimensions[dim] * self.weights.get(dim, 0) for dim in dimensions)

        # 5. 判定逻辑 (Gatekeeping)
        # 关键点：数学逻辑错误直接判定为不通过
        is_correct = ai_review.get('is_mathematically_correct', False)
        passed = (total_score >= 75) and is_correct and (dimensions['structure'] >= 80)

        # 汇总反馈给生成器（用于自愈）
        feedback = ai_review.get('critical_flaw', "") + " | " + ai_review.get('improvement_suggestion', "")
        if not is_correct:
            all_issues.append("FATAL: Mathematical logic error detected by AI Judge.")

        return EvaluationResult(
            score=round(total_score, 1),
            dimensions=dimensions,
            issues=all_issues,
            passed=passed,
            ai_feedback=feedback
        )