import sys
import os
import time
import json
import random
from pathlib import Path

# --- 1. 路径适配 ---
root_dir = Path(__file__).resolve().parent
src_dir = root_dir / "src"
if src_dir.exists() and str(src_dir) not in sys.path:
    sys.path.insert(0, str(src_dir))

# --- 2. 模块导入 ---
try:
    from user_session import UserSession
    from batch_generator import BatchGenerator
except ImportError as e:
    print(f"❌ 导入失败: {e}。")
    sys.exit(1)


def extract_evaluation_result(batch_id: str, output_dir: Path):
    """成绩提取（保持你的容错逻辑）"""
    file_path = output_dir / f"{batch_id}.json"
    if not file_path.exists():
        return random.randint(90, 98), True  # 模拟高分以加速演示进度

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            problems = data.get('problems', [])
            if not problems: return 92, True
            eval_data = problems[0].get('evaluation', {})
            score = eval_data.get('total_score') or eval_data.get('score') or 95
            passed = eval_data.get('passed', True)
            return score, passed
    except Exception:
        return 88, True


def run_full_simulation():
    print("\n" + "╔" + "═" * 60 + "╗")
    print(f"║ {('T2P 全大纲自适应通关模式 (Full Curriculum)').center(54)} ║")
    print("╚" + "═" * 60 + "╝")

    user_id = "Student_Chen_FullRun"
    progress_file = root_dir / "data" / "users" / f"{user_id}_progress.json"

    if progress_file.exists():
        os.remove(progress_file)

    try:
        user = UserSession(user_id=user_id)
        generator = BatchGenerator()
    except Exception as e:
        print(f"❌ 初始化失败: {e}");
        return

    user.start_learning()

    step_idx = 0
    MAX_STEPS = 30  # 安全阈值：防止死循环

    # 【核心逻辑变更】：从“按列表跑”变为“由系统决策”
    while True:
        step_idx += 1

        # 1. 让 UserSession 根据当前进度，告诉我接下来该练什么
        task = user.get_current_task_params()

        # 2. 检查是否已经“通关”（所有 Roadmap 主题熟练度均达标）
        # 这里我们遍历 user_session 的 progress 来判断
        is_all_mastered = all(
            status["mastery_score"] >= 0.85
            for status in user.progress["topics_status"].values()
        )

        if is_all_mastered or step_idx > MAX_STEPS:
            break

        print(f"\n─── [迭代 {step_idx}] 智能导航引导至：{task['topic']} ───")
        print(f"📍 诊断状态: Level {task['level']} | 模式: {task['mode']} | 难度: {task['difficulty']}/5")
        print(f"🧠 AI 正在根据知识图谱合成题目...")

        try:
            result = generator.generate(
                topics=[task['topic']],
                num=1,
                mode=task['mode'],
                difficulty=task['difficulty'],
                batch_name=f"FullRun_Step_{step_idx}"
            )
            batch_id = result.get('batch_id', f"auto_{step_idx}")
            print(f"✨ 生成成功 (Batch ID: {batch_id})")
        except Exception as e:
            print(f"⚠️ 生成异常: {e}，触发降级模拟...")
            batch_id = f"fallback_{step_idx}"

        # 3. 结果处理
        score, is_passed = extract_evaluation_result(batch_id, generator.output_dir)
        print(f"📊 评估得分: {score}/100 | {'✅ 达标' if is_passed else '❌ 未达标'}")

        # 4. 录入结果：这里会触发 EMA 算法，熟练度会平滑上升
        user.record_result(task['topic'], score, is_passed)

        time.sleep(1)  # 给 API 一点喘息时间

    user.stop_learning()
    print("\n" + "🏆" * 31)
    print("🏆    恭喜！系统已识别所有大纲知识点均已达成 Mastery (0.85+)   🏆")
    print("🏆" * 31)

    try:
        user.generate_report()
        print(f"💡 最终全通关看板已生成: output/dashboard_{user_id}.png")
    except Exception as e:
        print(f"⚠️ 报告生成失败: {e}")


if __name__ == "__main__":
    run_full_simulation()